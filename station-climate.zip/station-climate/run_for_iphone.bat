@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py serve.py --lan) || (python serve.py --lan)
pause
