# Station Climate

A Weatherspark-style climate website for airport weather stations (ASOS and AWOS), built from each station's own observation history instead of reanalysis. Everything is in one file, `index.html`.

## Running it

1. Open `index.html` in Chrome or Edge, enter a station ID (KCON, or the 3-letter FAA ID), choose the years, and select **Build report**. The default period ends with the current year so the climate graphs can show recent days.
2. If it says the browser could not reach the data service, double-click `run_local_helper.bat` (or run `python serve.py`) and use `http://localhost:8765`. The helper needs only standard Python and only relays requests to IEM, api.weather.gov and NOAA's station history service.
3. For an iPhone or iPad on the same Wi-Fi, use `run_for_iphone.bat` (or `python serve.py --lan`) and open the address it prints in Safari.

The first 20-year download takes about a minute. Downloads are cached in the browser, so later visits are quick; **Settings** clears the cache.

Every page has its own link, so you can bookmark or share any of them. The links take this form:

| Page | Example link |
|---|---|
| Station page | `#/KCON/2006-2025/records` |
| Comparison | `#/compare/2006-2025/KCON,KPSM,KBOS` |

## Pages

| Page | What it shows |
|---|---|
| **Climate** | The year-round climate page: temperature, clouds, precipitation and snow, sun and moon, humidity, wind, heat index and wind chill, UTCI thermal stress, air density and pressure, flight categories, storms/fog/icing and intensity, degree days, tourism score, growing season, solar energy, data coverage |
| **Months** | One page per month: every climate chart zoomed to the month, month-specific text, records, wind rose, and every year's version of that month |
| **History: year** | Observed daily highs and lows over the climatology bands and records, daily precipitation with running total versus normal, snowfall and depth, sky cover, dew point, wind, and a month-by-month departures table |
| **History: month** | Hourly temperature, dew point, precipitation, sky cover and wind, plus a day-by-day table |
| **History: day** | Hourly charts and observations, every report including specials with the raw METAR text, and optional 1-minute wind |
| **Climate graphs** | NWS-style climate graphs for the last 30 days, a month, or a year (calendar, water year or snow season). Shows observed daily highs and lows over the normal range and records (diamonds mark records set or tied), departures from normal, and running precipitation and snowfall against normal. A stats panel gives departures, records and ranks. **Compare years** overlays running totals (precipitation, snow, degree days, average temperature) for any years against the normal and the record range. Normals come from this record or from the NWS 1991–2020 normals |
| **Monthly tables** | NOWData-style tables: every month of every year for one variable (means, extremes, totals, or days past a threshold), shaded by rank. Click a column heading to rank the years and chart them, or a value to open that month |
| **Records** | Daily and monthly records, top-10 lists, return periods (GEV and Gumbel fits with bootstrap bands), longest streaks, first and last dates |
| **Trends** | Temperature stripes, 16 annual or seasonal series with Sen's slope and Mann-Kendall tests, a two-period comparison, and a check against NWS normals |
| **Data quality** | Coverage by variable, reporting changes by year, wind index, homogeneity tests (Pettitt, SNHT), neighbor ratio tests, NOAA station history, flagged values, hourly CSV export |
| **Events** | Find every day meeting a condition, with counts by year and month and links to each day |
| **Explore** | Conditional climatology: filter hours by month, hour, precipitation, wind, temperature, sky or flight category, then see the wind rose, distributions and timing |
| **1-minute wind** | One month of ASOS 1-minute wind: METAR versus true hourly means, gust factors, within-hour variability |
| **Compare** | Up to four stations side by side, year round or for one month |

## Chart interaction

- **Hover:** read the values.
- **Buttons:** **Data**, **CSV** and **PNG** export each chart.
- **Click on climatology charts:** opens a table built for that chart, with one row per year for the chosen date, hour or month. A ±3, ±7 or ±15 day window can widen it. Arrow keys step through dates.
- **Click on history, records and event charts:** opens the day's history page.

## Data sources

- **Hourly observations:** routine and special METARs from the Iowa Environmental Mesonet archive (`asos.py`), including temperature, dew point, wind, gusts, peak-wind remarks, sky cover and ceilings, visibility, pressure, precipitation, present weather and ice accretion.
- **Daily climate-report values:** snowfall, snow depth and liquid totals, through IEM daily summaries (`daily.py`). These exist only for stations with an NWS daily climate report.
- **Neighbor comparisons and NWS normals:** IEM daily summaries and network station lists.
- **1-minute wind:** IEM's archive of NCEI 1-minute ASOS data (`asos1min.py`), 2000 onward, ASOS only, about a day behind real time. If IEM fails, the page reads NCEI's monthly page-1 files directly. Reaching NCEI may need the local helper (`serve.py`) if the browser blocks the request. When both fail, the page shows what each source returned and a link to open the IEM request in a new tab.
- **Station history:** NOAA's Historical Observing Metadata Repository (HOMR).
- **Station location, time zone and state:** api.weather.gov.

## Methods notes

- **Sky cover:** ASOS and AWOS ceilometers see only to about 12,000 ft, so clear categories read high.
- **Sunshine estimate:** estimated hourly from sky cover (Haurwitz clear sky, Kasten-Czeplak cloud reduction). This estimate is used in UTCI and solar energy, and it leans high for the same reason as sky cover.
- **UTCI:** the official polynomial. Mean radiant temperature uses a sky/ground longwave split and ASHRAE 55 SolarCal for a standing person.
- **Heat index and wind chill:** NWS formulas, applied only within their defined ranges.
- **Air density:** from the altimeter setting reduced to station pressure, with virtual temperature from the dew point.
- **Return periods:** fitted to annual extremes (July-to-June seasons for cold extremes) by L-moments. With 20 years, levels beyond about 40 years are extrapolations.
- **Trend tests:** no autocorrelation correction. Single-station homogeneity tests cannot separate a sensor change from a climate shift; use the neighbor test for that.
- **Snow-to-liquid ratios:** the climatology uses snow-only days with at least 1 in of snow and 0.05 in of liquid.

## Extending it

The code is in `index.html`, organized as these modules:

| Module | Role |
|---|---|
| `Core` | Shared utilities |
| `Astro` | Sun and moon |
| `Data` | Downloads |
| `Analysis`, `Analysis2` | Climatology, records, trends, quality |
| `Detail` | Click tables |
| `Charts`, `Charts2` | Chart builders |
| `Pages` | Page renderers |
| `UI` | Router and page shell |
