#!/usr/bin/env python3
"""
Station Climate helper (standard library only, no installs).

Serves index.html and relays the page's data requests to the two services it uses
(IEM, api.weather.gov and NOAA HOMR). The page tries the services directly first and only
falls back to this relay if the browser blocks the request.

    python serve.py              this computer only: http://localhost:8765
    python serve.py --lan        also phones and tablets on the same Wi-Fi
                                 (or double-click run_for_iphone.bat)
    python serve.py 9000         use another port
    python serve.py --no-browser do not open a browser window

Only index.html and README.md are served, and only IEM, api.weather.gov and NOAA HOMR are
relayed, so nothing else in this folder or on this computer is exposed.
"""
import http.server
import os
import socket
import socketserver
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

PORT = next((int(a) for a in sys.argv[1:] if a.isdigit()), 8765)
LAN = "--lan" in sys.argv
ALLOWED_HOSTS = {"mesonet.agron.iastate.edu", "api.weather.gov", "www.ncei.noaa.gov"}
SERVED_FILES = {"/index.html": "text/html; charset=utf-8", "/README.md": "text/markdown; charset=utf-8"}
HERE = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "StationClimate/1.1"

    def log_message(self, fmt, *args):
        # keep the console readable: trim long query strings
        sys.stderr.write("%s  %s\n" % (self.client_address[0], (fmt % args)[:200]))

    def _send(self, status, body, ctype, head_only=False):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if not head_only:
            self.wfile.write(body)

    def _handle(self, head_only=False):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path or "/"
        if path == "/proxy/health":
            return self._send(200, b"ok", "text/plain", head_only)
        if path == "/proxy":
            target = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            t = urllib.parse.urlparse(target)
            if t.scheme != "https" or t.hostname not in ALLOWED_HOSTS:
                return self._send(403, b"This helper only relays requests to IEM, api.weather.gov and NOAA HOMR.", "text/plain", head_only)
            req = urllib.request.Request(target, headers={
                "User-Agent": "StationClimate/1.1 (local helper)",
                "Accept": "*/*",
            })
            try:
                with urllib.request.urlopen(req, timeout=240) as r:
                    return self._send(r.status, r.read(), r.headers.get("Content-Type", "application/octet-stream"), head_only)
            except urllib.error.HTTPError as e:
                return self._send(e.code, e.read(), e.headers.get("Content-Type", "text/plain"), head_only)
            except Exception as e:  # network, TLS, timeout
                return self._send(502, ("Relay failed: %s" % e).encode(), "text/plain", head_only)
        if path == "/":
            path = "/index.html"
        if path in SERVED_FILES:
            try:
                with open(os.path.join(HERE, path.lstrip("/")), "rb") as f:
                    return self._send(200, f.read(), SERVED_FILES[path], head_only)
            except OSError:
                pass
        return self._send(404, b"Not found", "text/plain", head_only)

    def do_GET(self):
        self._handle()

    def do_HEAD(self):
        self._handle(head_only=True)


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def lan_addresses():
    """IPv4 addresses other devices on the network can use to reach this computer."""
    ips = set()
    try:  # the interface used for outbound traffic (no packet is actually sent)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        ips.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith(("127.", "169.254.", "0.")))


def main():
    host = "0.0.0.0" if LAN else "127.0.0.1"
    local = "http://localhost:%d/" % PORT
    try:
        httpd = Server((host, PORT), Handler)
    except OSError as e:
        print("Could not start on port %d (%s). Try another port, for example: python serve.py 9000" % (PORT, e))
        input("Press Enter to close.") if os.name == "nt" else None
        return
    with httpd:
        print("Station Climate is running. Press Ctrl+C to stop.\n")
        print("  On this computer:  %s" % local)
        if LAN:
            ips = lan_addresses()
            if ips:
                print("\n  On your iPhone or iPad (same Wi-Fi), open in Safari:")
                for ip in ips:
                    print("      http://%s:%d/" % (ip, PORT))
                print("\n  If the phone cannot connect:")
                print("   - When Windows asks, allow Python on Private networks (or allow it in Windows")
                print("     Defender Firewall), and make sure this Wi-Fi is set to a Private network.")
                print("   - Office and guest Wi-Fi often block device-to-device traffic; home Wi-Fi usually works.")
            else:
                print("\n  No network address found. Is this computer connected to Wi-Fi or Ethernet?")
        else:
            print("\n  To use it from an iPhone or iPad on the same Wi-Fi, run:  python serve.py --lan")
        print()
        if "--no-browser" not in sys.argv:
            threading.Timer(0.8, lambda: webbrowser.open(local)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    main()
